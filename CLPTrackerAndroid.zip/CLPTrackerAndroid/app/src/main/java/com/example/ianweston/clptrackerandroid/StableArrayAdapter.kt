package com.example.ianweston.clptrackerandroid

import android.content.Context
import android.widget.ArrayAdapter

open class StableArrayAdapter(context: Context, textViewResourceId: Int, objects: List<String>) :
    ArrayAdapter<String>(context, textViewResourceId, objects) {
    private var idMap = HashMap<String, Int>()

    init {
        var i  = 0
        objects.forEach()
        {
            idMap[it] = i
            i++
        }
    }

    override fun getItemId(position: Int): Long {
        val item = getItem(position)
        return idMap[item]!!.toLong()
    }

    override fun hasStableIds(): Boolean {
        return true
    }
}