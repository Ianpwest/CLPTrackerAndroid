package com.example.ianweston.clptrackerandroid

import android.Manifest
import android.Manifest.permission.ACCESS_COARSE_LOCATION
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.RemoteException
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.ListAdapter
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_home.*
import org.altbeacon.beacon.BeaconConsumer
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.MonitorNotifier
import org.altbeacon.beacon.Region


class HomeActivity : BeaconConsumer, AppCompatActivity() {
    private val PERMISSION_REQUEST_COARSE_LOCATION = 1
    private var beaconManager: BeaconManager? = null
    private val TAG = "MonitoringActivity"

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                message.setText(R.string.title_home)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
                message.setText(R.string.title_dashboard)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                message.setText(R.string.title_notifications)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                var builder: AlertDialog.Builder = AlertDialog.Builder(this)
                builder.setTitle("CLP Tracker must access bluetooth to scan for CLP courses.")
                builder.setPositiveButton(android.R.string.ok, null)
                builder.setOnDismissListener {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), PERMISSION_REQUEST_COARSE_LOCATION)
                }

                builder.show()
            }
        }

        beaconManager = BeaconManager.getInstanceForApplication(this)
        beaconManager!!.bind(this)

        // Show a list of connected devices
        val bluetoothDevicesList : ListView = findViewById(R.id.bluetooth_list_view)
        val values = listOf("Device 1", "Device 2", "Device 3")

        val listAdapter = StableArrayAdapter(this,
            android.R.layout.simple_list_item_1, values)

        bluetoothDevicesList.adapter = listAdapter

        // Show a navigation drawer
        //if you want to update the items at a later time it is recommended to keep it in a variable
        val item1 = PrimaryDrawerItem().withIdentifier(1).withName(R.string.drawer_item_home)
        val item2 = SecondaryDrawerItem().withIdentifier(2).withName(R.string.drawer_item_settings)

        //create the drawer and remember the `Drawer` result object
        val result = DrawerBuilder()
            .withActivity(this)
            .withToolbar(toolbar)
            .addDrawerItems(
                item1,
                DividerDrawerItem(),
                item2,
                SecondaryDrawerItem().withName(R.string.drawer_item_settings)
            )
            .withOnDrawerItemClickListener(object : Drawer.OnDrawerItemClickListener() {
                fun onItemClick(view: View, position: Int, drawerItem: IDrawerItem): Boolean {
                    // do something with the clicked item :D
                }
            })
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        beaconManager!!.unbind(this)
    }

    override fun onBeaconServiceConnect() {
        var monitorNotifier = object : MonitorNotifier {
            override fun didDetermineStateForRegion(state: Int, region: Region?) {
                Log.i(TAG, "I have just switched from seeing/not seeing beacons: $state")
            }

            override fun didExitRegion(region: Region?) {
                Log.i(TAG, "I no longer see an beacon")
            }

            override fun didEnterRegion(region: Region?){
                Log.i(TAG, "I just saw an beacon for the first time!")
            }
        }

        beaconManager!!.addMonitorNotifier(monitorNotifier)

        try {
            beaconManager!!.startMonitoringBeaconsInRegion(Region("CLPTrackerBeaconMonitor", null, null, null))
        }
        catch (e: RemoteException) {
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when(requestCode)
        {
            PERMISSION_REQUEST_COARSE_LOCATION ->
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    Log.d("Debug", "Coarse location permission granted")
                }
                else
                {
                    var builder: AlertDialog.Builder = AlertDialog.Builder(this)
                    builder.setTitle("Functionality limited")
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover CLP courses.")
                    builder.setPositiveButton(android.R.string.ok, null)
                    builder.show()
                }
        }
    }
}

class BluetoothDevice{
    var DeviceName = ""
}